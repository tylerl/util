package Cpanel::Easy::ModCloudflare;
# Created by Tyler Larson based on easyapache module for mod_rpaf 
our $easyconfig = {
    'version' => '$Rev: 1 $',
    'name'    => 'Mod CloudFlare',
    'note'    => 'CloudFlare reverse proxy support',
    'url'     => 'https://www.cloudflare.com/wiki/Log_Files',
    'src_cd2' => 'mod_cloudflare',
    'hastargz' => 1,
    'step'    => {
        '0' => {
            'name'    => 'Compiling, installing, and activating',
            'command' => sub {
                my ($self) = @_;
                my ($rc, @msg) = $self->run_system_cmd_returnable( [ $self->_get_main_apxs_bin(), qw(-i -a -c mod_cloudflare.c)] );
                if (!$rc) { $self->print_alert_color('red', q{apxs mod_cloudflare.c failed}); }
                return ($rc, @msg);
            },            
        },
    },    
}; 
1;
